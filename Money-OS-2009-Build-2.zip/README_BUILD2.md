# Money OS 2009 — Build 2.0

Upload all files in this package to the root of your GitHub repository.

Then enable GitHub Pages:
Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save.

This public build contains no personal financial values. Browser-entered values are stored locally.
