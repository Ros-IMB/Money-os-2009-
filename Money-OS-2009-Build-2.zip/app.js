const K='moneyOS2009_v2';
const D={checking:0,savings:0,cushion:0,buckets:{bills:0,personal:0,debt:0,buffer:0},payday:{paycheck:0,savePct:15,personalPct:10,debtTarget:0,lastSplit:null},bills:[],debt:{balance:0,apr:0,payment:0,extra:0},savingsGoal:3000};
const $=x=>document.getElementById(x), money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(+n||0);
function merge(a,b){if(!b||typeof b!='object')return structuredClone(a);let o=structuredClone(a);for(const k in b)o[k]=(b[k]&&typeof b[k]=='object'&&!Array.isArray(b[k])&&o[k]&&typeof o[k]=='object'&&!Array.isArray(o[k]))?merge(o[k],b[k]):b[k];return o}
let s;try{s=merge(D,JSON.parse(localStorage.getItem(K)||'null'))}catch{s=structuredClone(D)}
function save(){localStorage.setItem(K,JSON.stringify(s));$('saveStatus').textContent='SAVED ✓';setTimeout(()=>$('saveStatus').textContent='READY',900)}
function n(id){return Math.max(0,+$(id).value||0)}
function safe(){return Math.max(0,s.checking-s.cushion-s.buckets.bills-s.buckets.debt)}
function billsNeed(){return s.bills.filter(b=>!b.paid).reduce((t,b)=>t+b.amount,0)}
function split(){let p=s.payday.paycheck,left=p,b=Math.min(left,Math.max(0,billsNeed()-s.buckets.bills));left-=b;let sv=Math.min(left,p*s.payday.savePct/100);left-=sv;let pe=Math.min(left,p*s.payday.personalPct/100);left-=pe;let d=Math.min(left,s.payday.debtTarget);left-=d;return{bills:b,savings:sv,personal:pe,debt:d,buffer:left}}
function render(){
 $('checking').value=s.checking||'';$('savings').value=s.savings||'';$('cushion').value=s.cushion||'';
 $('paycheck').value=s.payday.paycheck||'';$('savePct').value=s.payday.savePct;$('personalPct').value=s.payday.personalPct;$('debtTarget').value=s.payday.debtTarget||'';
 $('debtBalance').value=s.debt.balance||'';$('debtApr').value=s.debt.apr||'';$('debtPayment').value=s.debt.payment||'';$('debtExtra').value=s.debt.extra||'';$('savingsGoal').value=s.savingsGoal||'';
 $('safeSpend').textContent=money(safe());$('billsReserved').textContent=money(s.buckets.bills);$('personalBucket').textContent=money(s.buckets.personal);$('debtBucket').textContent=money(s.buckets.debt);$('freeBuffer').textContent=money(s.buckets.buffer);
 const mb=s.bills.reduce((t,b)=>t+b.amount,0);$('shieldScore').textContent=mb?Math.min(100,Math.round((s.savings+s.buckets.bills)/mb*50)):(s.checking?40:0);
 $('heroMessage').textContent=billsNeed()?`${money(billsNeed())} in active bills are waiting.`:'No active unpaid bills.';
 const q=s.payday.lastSplit||split();$('splitBills').textContent=money(q.bills);$('splitSavings').textContent=money(q.savings);$('splitPersonal').textContent=money(q.personal);$('splitDebt').textContent=money(q.debt);$('splitBuffer').textContent=money(q.buffer);
 const pct=s.savingsGoal?Math.min(100,s.savings/s.savingsGoal*100):0;$('savingsBar').style.width=pct+'%';$('savingsProgress').textContent=Math.round(pct)+'%';
 $('billList').innerHTML=s.bills.length?s.bills.map((b,i)=>`<div class="bill"><p><strong>${b.name}</strong><strong>${money(b.amount)}</strong></p><small>Due day ${b.day}</small><button onclick="togglePaid(${i})">${b.paid?'UNDO PAID':'MARK PAID'}</button><button onclick="removeBill(${i})">REMOVE</button></div>`).join(''):'<div class="card">No bills yet.</div>';
}
function bind(id,path){$(id).oninput=()=>{let o=s,p=path.split('.');for(let i=0;i<p.length-1;i++)o=o[p[i]];o[p.at(-1)]=n(id);save();render()}}
['checking','savings','cushion'].forEach(x=>bind(x,x));bind('paycheck','payday.paycheck');bind('savePct','payday.savePct');bind('personalPct','payday.personalPct');bind('debtTarget','payday.debtTarget');bind('debtBalance','debt.balance');bind('debtApr','debt.apr');bind('debtPayment','debt.payment');bind('debtExtra','debt.extra');bind('savingsGoal','savingsGoal');
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab,.panel').forEach(x=>x.classList.remove('active'));b.classList.add('active');$(b.dataset.tab).classList.add('active')});
$('previewPayday').onclick=()=>{s.payday.lastSplit=split();save();render()};
$('commitPayday').onclick=()=>{let q=s.payday.lastSplit||split(),p=s.payday.paycheck;if(!p)return alert('Enter a paycheck first.');s.checking+=p;s.buckets.bills+=q.bills;s.savings+=q.savings;s.buckets.personal+=q.personal;s.buckets.debt+=q.debt;s.buckets.buffer+=q.buffer;s.payday.lastSplit=null;save();render()};
$('addBill').onclick=()=>{let name=$('billName').value.trim(),amount=n('billAmount'),day=Math.max(1,Math.min(31,Math.round(n('billDay'))));if(!name||!amount)return alert('Enter bill name and amount.');s.bills.push({name,amount,day,paid:false});$('billName').value=$('billAmount').value=$('billDay').value='';save();render()};
window.togglePaid=i=>{let b=s.bills[i];b.paid=!b.paid;if(b.paid){s.buckets.bills=Math.max(0,s.buckets.bills-b.amount);s.checking=Math.max(0,s.checking-b.amount)}save();render()};
window.removeBill=i=>{s.bills.splice(i,1);save();render()};
function debt(){let bal=s.debt.balance,r=s.debt.apr/1200,p=s.debt.payment+s.debt.extra,m=0,int=0;if(!bal||!p){$('payoffMonths').textContent='—';$('payoffInterest').textContent='—';$('totalDebtPayment').textContent=money(p);return}while(bal>0&&m<1200){let x=bal*r;if(p<=x&&r){m=Infinity;break}int+=x;bal+=x;bal-=Math.min(p,bal);m++}$('payoffMonths').textContent=isFinite(m)?m:'Payment too low';$('payoffInterest').textContent=isFinite(m)?money(int):'—';$('totalDebtPayment').textContent=money(p)}
$('runDebt').onclick=debt;
$('exportData').onclick=()=>{let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(s,null,2)],{type:'application/json'}));a.download='money-os-backup.json';a.click()};
$('importData').onchange=async e=>{try{s=merge(D,JSON.parse(await e.target.files[0].text()));save();render()}catch{alert('Could not read backup.')}};
$('resetData').onclick=()=>{if(confirm('Reset all saved Money OS data in this browser?')){s=structuredClone(D);save();render()}};
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
render();debt();